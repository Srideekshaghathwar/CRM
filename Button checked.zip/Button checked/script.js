document.querySelectorAll('input[type="checkbox"]').forEach(cb => {
  cb.addEventListener("change", () => {
    console.log("Checked:", cb.value, cb.checked);
  });
});
