import "./MediumCheckbox.css";

export default function MediumCheckbox({ title = "Checkbox Checked", options = [], values = [], onChange }) {

  const handleChange = (val) => {
    if (values.includes(val)) {
      onChange(values.filter(v => v !== val));
    } else {
      onChange([...values, val]);
    }
  };

  return (
    <div className="mc-wrapper">
      <div className="mc-title">
        <span className="mc-icon">❖</span>
        {title}
      </div>

      <div className="mc-box">
        {options.map(option => (
          <label key={option.value} className="mc-option">
            <input
              type="checkbox"
              checked={values.includes(option.value)}
              onChange={() => handleChange(option.value)}
              className="mc-input"
            />
            <span className="mc-checkbox"></span>
          </label>
        ))}
      </div>
    </div>
  );
}
