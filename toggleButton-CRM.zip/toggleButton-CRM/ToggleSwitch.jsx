import "./ToggleSwitch.css";

export default function ToggleSwitch({ title = "Toggle Button", checked = false, onChange }) {
  return (
    <div className="ts-wrapper">
      <div className="ts-title">
        <span className="ts-icon">❖</span>
        {title}
      </div>

      <div className="ts-box">
        <label className="ts-toggle">
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => onChange(e.target.checked)}
          />
          <span className="ts-slider"></span>
        </label>
      </div>
    </div>
  );
}
