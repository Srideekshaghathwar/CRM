document.querySelectorAll(".toggle input").forEach(toggle => {
  toggle.addEventListener("change", () => {
    console.log("Toggle state:", toggle.checked);
  });
});
