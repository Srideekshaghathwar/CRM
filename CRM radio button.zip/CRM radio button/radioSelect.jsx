import "./RadioSelect.css";

export default function RadioSelect({ title = "Radio Selected", options = [], value, onChange }) {
  return (
    <div className="rs-wrapper">
      <div className="rs-title">
        <span className="rs-icon">❖</span>
        {title}
      </div>

      <div className="rs-box">
        {options.map((option) => (
          <label key={option.value} className="rs-option">
            <input
              type="radio"
              name="radio-selected"
              value={option.value}
              checked={value === option.value}
              onChange={(e) => onChange(e.target.value)}
              className="rs-input"
            />
            <span className="rs-custom-radio"></span>
          </label>
        ))}
      </div>
    </div>
  );
}
