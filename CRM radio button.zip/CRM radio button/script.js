document.querySelectorAll('input[name="choice"]').forEach(radio => {
  radio.addEventListener("change", () => {
    console.log("Selected:", radio.value);
  });
});
