const calendar = document.getElementById("calendar");
const monthTitle = document.getElementById("monthTitle");

let currentMonth = 8; // 0-based index (8 = September)
let currentYear = 2022;

// Events for August 2022
const augustEvents = [
  { start: 29, end: 29, text: "Team meeting 10:00 AM", class: "purple", icon: "fa-users" }
];

// Events for September 2022
const septemberEvents = [
  { start: 1, end: 1, text: "Client call 2:00 PM", class: "blue", icon: "fa-phone" },
  { start: 2, end: 2, text: "Demo presentations", class: "teal", icon: "fa-tv" },
  { start: 6, end: 6, text: "Follow up emails", class: "green", icon: "fa-envelope" },
  { start: 9, end: 9, text: "Sales review 3:00 PM", class: "orange", icon: "fa-chart-bar" },
  { start: 13, end: 15, text: "Trade Show (3 days)", class: "blue", icon: "fa-plane" },
  { start: 21, end: 21, text: "Quarterly planning 11:00AM", class: "purple", icon: "fa-calendar" },
  { start: 23, end: 24, text: "Product launch 4:00 PM", class: "pink", icon: "fa-rocket" },
  { start: 29, end: 30, text: "Contract signing 5:00 PM", class: "green", icon: "fa-handshake" }
];

const monthNames = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December"
];

function generateCalendar(month, year) {
  calendar.innerHTML = "";

  const firstDay = new Date(year, month, 1).getDay();
  const totalDays = new Date(year, month + 1, 0).getDate();

  monthTitle.innerText = monthNames[month] + " " + year;

  // Empty boxes before month start
  for (let i = 0; i < firstDay; i++) {
    const empty = document.createElement("div");
    empty.className = "day";
    calendar.appendChild(empty);
  }

  // Choose events for month
  let eventsToUse = [];
  if (year === 2022 && month === 7) eventsToUse = augustEvents;
  if (year === 2022 && month === 8) eventsToUse = septemberEvents;

  // Generate days
  for (let day = 1; day <= totalDays; day++) {

    const dayBox = document.createElement("div");
    dayBox.className = "day";
    dayBox.style.position = "relative";
    dayBox.style.overflow = "visible";

    const date = document.createElement("div");
    date.className = "date-number";
    date.innerText = day.toString().padStart(2, "0");

    dayBox.appendChild(date);

    // Render events ONLY on start date
    eventsToUse.forEach(eventData => {

      if (day === eventData.start) {

        const event = document.createElement("div");
        event.className = "event " + eventData.class;

      const totalSpan = eventData.end - eventData.start + 1;

// find what day of week this date is (0 = Sunday)
const dayIndex = (firstDay + day - 1) % 7;

// how many days left in this week
const daysLeftInWeek = 7 - dayIndex;

// do not allow event to cross week boundary
const spanDays = Math.min(totalSpan, daysLeftInWeek);

event.style.position = "absolute";
event.style.top = "22px";
event.style.left = "2px";

event.style.width = `calc(${spanDays * 100}% - 22px)`;



        event.innerHTML =
          `<i class="fa ${eventData.icon}"></i> ${eventData.text}`;

        event.onclick = () => {
          alert(eventData.text);
        };

        dayBox.appendChild(event);
      }

    });

    calendar.appendChild(dayBox);
  }
}

generateCalendar(currentMonth, currentYear);

// PREVIOUS BUTTON
document.getElementById("prevMonth").onclick = () => {
  currentMonth--;
  if (currentMonth < 0) {
    currentMonth = 11;
    currentYear--;
  }
  generateCalendar(currentMonth, currentYear);
};

// NEXT BUTTON
document.getElementById("nextMonth").onclick = () => {
  currentMonth++;
  if (currentMonth > 11) {
    currentMonth = 0;
    currentYear++;
  }
  generateCalendar(currentMonth, currentYear);
};

// New Event Button
document.querySelector(".new-event-btn").onclick = () => {
  const title = prompt("Enter event title:");
  if (title) {
    alert("Event '" + title + "' created (demo only)");
  }
};


// View Buttons Toggle
document.querySelectorAll(".view").forEach(btn => {
  btn.onclick = () => {

    document.querySelectorAll(".view").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    const viewType = btn.innerText;

    if (viewType === "Month") {
      generateCalendar(currentMonth, currentYear);
    }

    if (viewType === "Week") {
      alert("Week view coming soon");
    }

    if (viewType === "Day") {
      alert("Day view coming soon");
    }

    if (viewType === "Today") {
      const today = new Date();
      currentMonth = today.getMonth();
      currentYear = today.getFullYear();
      generateCalendar(currentMonth, currentYear);
    }
  };
});

// Filter Toggle
document.querySelectorAll(".filter").forEach(btn => {
  btn.onclick = () => {

    document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    const type = btn.innerText.trim();

    if (type === "Export") {
      alert("Exporting calendar...");
      return;
    }

    alert(type + " filter applied");
  };
});

