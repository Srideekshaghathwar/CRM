import './styles.css'

const Card = () => (
  <div className="card">
    <h4>Welcome Email</h4>
    <div className="status">Success</div>
    <p>Lead Created</p>
    <div className="user">
      <div className="avatar">JS</div>
      <div>
        <strong>john.smith@acme.com</strong><br/>
        <small>Jan 22, 2024</small>
      </div>
    </div>
  </div>
)

export default function App(){
  return (
    <div className="app">
      <div className="sidebar">...</div>
      <div className="email-sidebar">...</div>

      <main className="main">
        <div className="topbar">
          <h2>Automation Logs</h2>
          <div className="top-actions">
            <input placeholder="Search emails..." />
            <button>Refresh</button>
            <button>Export</button>
          </div>
        </div>

        <div className="stats">
          <div className="stat"><p>Total Executed</p><h3>3,842</h3></div>
          <div className="stat"><p>Successful</p><h3>3,654 <b className="green">95%</b></h3></div>
          <div className="stat"><p>Failed</p><h3>142 <b className="red">4%</b></h3></div>
          <div className="stat"><p>Pending</p><h3>46</h3></div>
        </div>

        <div className="filters">
          <input placeholder="Search logs..." />
          <select><option>All Automations</option></select>
          <select><option>All Status</option></select>
          <select><option>Last 7 Days</option></select>
        </div>

        <div className="action-bar">
          <div>Showing 1-12 of 24 emails</div>
          <div>
            <button>1</button><button>2</button><button>3</button>
          </div>
        </div>

        <div className="grid">
  {Array.from({ length: 12 }).map((_, i) => (
    <Card key={i} />
  ))}
</div>
      </main>
    </div>
  )
}
