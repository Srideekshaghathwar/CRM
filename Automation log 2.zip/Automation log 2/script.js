const grid = document.getElementById("grid");
const viewBtn = document.getElementById("viewBtn");
const viewMenu = document.getElementById("viewMenu");
const emailToggle = document.getElementById("emailToggle");
const emailMenu = document.getElementById("emailMenu");
const arrowIcon = emailToggle.querySelector("i");

document.querySelectorAll(".toggle").forEach(toggle => {
  const menu = document.getElementById(toggle.dataset.target);
  const icon = toggle.querySelector("i");

  menu.style.display = "none"; 

  toggle.addEventListener("click", () => {
    const open = menu.style.display === "block";
    menu.style.display = open ? "none" : "block";
    icon.style.transform = open ? "rotate(0deg)" : "rotate(180deg)";
  });
});

emailToggle.addEventListener("click", () => {
  const isOpen = emailMenu.style.display === "block";

  emailMenu.style.display = isOpen ? "none" : "block";
  arrowIcon.style.transform = isOpen ? "rotate(0deg)" : "rotate(180deg)";
});

viewBtn.addEventListener("click", () => {
  viewMenu.style.display =
    viewMenu.style.display === "block" ? "none" : "block";
});

document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.querySelector('[data-target="emailMenu"]');
  const menu = document.getElementById("emailMenu");
  const icon = toggle.querySelector("i");

  menu.style.display = "none";

  toggle.addEventListener("click", () => {
    const open = menu.style.display === "block";
    menu.style.display = open ? "none" : "block";
    icon.style.transform = open ? "rotate(0deg)" : "rotate(180deg)";
  });
});


window.addEventListener("load", function () {
  const tableBody = document.getElementById("tableBody");

  if (!tableBody) return;

  for (let i = 1; i <= 24; i++) {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>
        Jan 22, 2024<br>
        <small>10:45 AM</small>
      </td>

      <td>
        <strong>Welcome Email</strong><br>
        <small>New lead automation</small>
      </td>

      <td>
        Lead Created<br>
        <small>ID: #12845</small>
      </td>

      <td>
        john.smith@acme.com<br>
        <small>Acme Corp</small>
      </td>

      <td>
        <span class="status-pill">
          <i class="fas fa-check-circle"></i> Success
        </span>
      </td>

      <td class="actions">
        <i class="fas fa-eye"></i>
        <i class="fas fa-rotate-right"></i>
        <i class="fas fa-trash"></i>
      </td>
    `;

    tableBody.appendChild(row);
  }
});


if (list) {
  for (let i = 0; i < 24; i++) {
    const card = document.createElement("div");
    card.className = ".card";

    card.innerHTML = `
      <div class="card-header">
        <h4>Welcome Email</h4>
        <div class="card-actions">
          <i class="fas fa-eye"></i>
          <i class="fas fa-reply"></i>
          <i class="fas fa-trash"></i>
        </div>
      </div>

      <div class="status">Success</div>
      <p>Lead Created</p>

      <div class="user">
        <div class="avatar">JS</div>
        <div>
          <strong>john.smith@acme.com</strong><br>
          <small>Jan 22, 2024</small>
        </div>
      </div>
    `;

    grid.appendChild(card);
  }
  

window.addEventListener("load", function () {
  const cardsPerPage = 12;
  const cards = document.querySelectorAll(".card"); 
  const totalCards = cards.length;
  const totalPages = Math.ceil(totalCards / cardsPerPage);

  const pageInfo = document.getElementById("pageInfo");
  const pageButtons = document.querySelectorAll(".page-btn");
  const prevBtn = document.getElementById("prevPage");
  const nextBtn = document.getElementById("nextPage");

  let currentPage = 1;

  function showPage(page) {
    currentPage = page;

    cards.forEach((card, index) => {
      card.style.display =
        index >= (page - 1) * cardsPerPage && index < page * cardsPerPage
          ? "block"
          : "none";
    });

    const start = (page - 1) * cardsPerPage + 1;
    const end = Math.min(page * cardsPerPage, totalCards);
    pageInfo.textContent = `Showing ${start}-${end} of ${totalCards} emails`;

    pageButtons.forEach((btn, i) => {
      btn.classList.toggle("active", i + 1 === page);
    });
  }

  prevBtn?.addEventListener("click", () => {
    if (currentPage > 1) showPage(currentPage - 1);
  });

  nextBtn?.addEventListener("click", () => {
    if (currentPage < totalPages) showPage(currentPage + 1);
  });

  pageButtons.forEach((btn, index) => {
    btn.addEventListener("click", () => showPage(index + 1));
  });

  showPage(1);
});
}
