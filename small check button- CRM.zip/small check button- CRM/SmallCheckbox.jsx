import "./SmallCheckbox.css";

export default function SmallCheckbox({ title = "Checkbox Checked", options = [], values = [], onChange }) {

  const handleChange = (val) => {
    if (values.includes(val)) {
      onChange(values.filter(v => v !== val));
    } else {
      onChange([...values, val]);
    }
  };

  return (
    <div className="sc-wrapper">
      <div className="sc-title">
        <span className="sc-icon">❖</span>
        {title}
      </div>

      <div className="sc-box">
        {options.map(option => (
          <label key={option.value} className="sc-option">
            <input
              type="checkbox"
              checked={values.includes(option.value)}
              onChange={() => handleChange(option.value)}
              className="sc-input"
            />
            <span className="sc-checkbox"></span>
          </label>
        ))}
      </div>
    </div>
  );
}
