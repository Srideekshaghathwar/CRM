const e = React.createElement;

function App() {

  const allFields = [
    "First Name","Last Name","Email","Phone","Company","Job Title",
    "Status","Source","City","State","Owner","Created Date"
  ];

  const [selectedFields, setSelectedFields] = React.useState(allFields);
  const [format, setFormat] = React.useState("CSV");

  const exportLeads = () => {
    alert(
      `Exporting ${selectedFields.length} fields as ${format}`
    );
  };

  return e("div", { className: "app" },

    /* SIDEBAR */
    e("div", { className: "sidebar" },
      e("h2", null, "BizConnect CRM"),
      ["Dashboard","Leads","Contacts","Deals","Activities","Email","Reports","Calendar","Settings"]
        .map(item =>
          e("div", {
            className: "nav-item" + (item === "Leads" ? " active" : ""),
            key: item
          },
            e("div", { className: "icon" }),
            item
          )
        )
    ),

    /* MAIN */
    e("div", { className: "main" },

      e("div", { className: "top-bar" },
        e("h2", null, "Export Leads"),
        e("div", null,
          e("button", { className: "btn" }, "Cancel "),
          e("button", {
            className: "btn primary",
            onClick: exportLeads
          }, "Export Leads")
        )
      ),

      e("div", { className: "card" },

        e("div", { className: "section" },
  e("h4", null, "Export Format"),

  e("div", { className: "export-options" },

    /* CSV */
    e("div", {
      className: "export-card" + (format === "CSV" ? " active" : ""),
      onClick: () => setFormat("CSV")
    },
      e("div", { className: "export-left" },
        e("input", {
          type: "radio",
          checked: format === "CSV",
          onChange: () => setFormat("CSV")
        }),
        e("div", { className: "export-text" },
          e("h5", null, "CSV (Comma Separated)"),
          e("p", null, "Best for Excel and spreadsheet applications")
        )
      ),
      e("div", { className: "file-icon" })
    ),

    /* Excel */
    e("div", {
      className: "export-card" + (format === "Excel" ? " active" : ""),
      onClick: () => setFormat("Excel")
    },
      e("div", { className: "export-left" },
        e("input", {
          type: "radio",
          checked: format === "Excel",
          onChange: () => setFormat("Excel")
        }),
        e("div", { className: "export-text" },
          e("h5", null, "Excel (XLSX)"),
          e("p", null, "Native Excel format with formatting support")
        )
      ),
      e("div", { className: "file-icon" })
    ),

    /* PDF */
    e("div", {
      className: "export-card" + (format === "PDF" ? " active" : ""),
      onClick: () => setFormat("PDF")
    },
      e("div", { className: "export-left" },
        e("input", {
          type: "radio",
          checked: format === "PDF",
          onChange: () => setFormat("PDF")
        }),
        e("div", { className: "export-text" },
          e("h5", null, "PDF Document"),
          e("p", null, "Printable format, read-only")
        )
      ),
      e("div", { className: "file-icon" })
    )

  )
),
e("div", { className: "section" },
  e("h4", null, "Filter Records"),

  e("div", { className: "filters" },

    e("div", { className: "filter-group" },
      e("label", null, "Lead Status"),
      e("select", null,
        ["All Status", "New", "Contacted", "Qualified", "Won"]
          .map(o => e("option", { key: o }, o))
      )
    ),

    e("div", { className: "filter-group" },
      e("label", null, "Lead Source"),
      e("select", null,
        ["All Sources", "Website", "Email", "Referral", "Campaign"]
          .map(o => e("option", { key: o }, o))
      )
    ),

    e("div", { className: "filter-group" },
      e("label", null, "Lead Owner"),
      e("select", null,
        ["All Owners", "Admin", "Sales Team", "Manager"]
          .map(o => e("option", { key: o }, o))
      )
    ),

    e("div", { className: "filter-group" },
      e("label", null, "Date Range"),
      e("select", null,
        ["All Time", "Last 7 Days", "Last 30 Days", "This Month"]
          .map(o => e("option", { key: o }, o))
      )
    )

  )
),

        /* FIELDS */
        e("div", { className: "section" },
          e("h4", null, "Select Fields to Export"),
          e("div", { className: "fields" },
            allFields.map(field =>
              e("label", { key: field },
                e("input", {
                  type: "checkbox",
                  checked: selectedFields.includes(field),
                  onChange: () =>
                    setSelectedFields(prev =>
                      prev.includes(field)
                        ? prev.filter(f => f !== field)
                        : [...prev, field]
                    )
                }),
                " " + field
              )
            )
          )
        ),

        e("div", { className: "export-summary" },

  e("h4", null, "Export Summary"),

  e("div", { className: "summary-grid" },

    e("div", { className: "summary-label" }, "Total Records to Export"),
    e("div", { className: "summary-value" }, "1,284"),

    e("div", { className: "summary-label" }, "Selected Fields"),
    e(
      "div",
      { className: "summary-value" },
      `${selectedFields.length} of 12 fields`
    ),

    e("div", { className: "summary-label" }, "Estimated File Size"),
    e("div", { className: "summary-value" }, "~2.3 MB")

  )
)


      )
    )
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(e(App));
