document.querySelectorAll(".dropdown-header").forEach(header => {
    header.addEventListener("click", function () {

        const content = this.nextElementSibling;

        content.classList.toggle("show");

    });
});
