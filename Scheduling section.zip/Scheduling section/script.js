const toggle = document.getElementById("toggleThrottle");
const throttleBox = document.getElementById("throttleBox");

toggle.addEventListener("change", function () {
    if (this.checked) {
        throttleBox.style.background = "#f5d3e8";
    } else {
        throttleBox.style.background = "#dddddd";
    }
});


const scheduleBtn = document.getElementById("scheduleBtn");

scheduleBtn.addEventListener("click", function () {

    const date = document.querySelector('input[type="date"]').value;
    const time = document.querySelector('input[type="time"]').value;

    if (!date || !time) {
        alert("Please select date and time");
        return;
    }

    alert("Email Scheduled Successfully!");
});
