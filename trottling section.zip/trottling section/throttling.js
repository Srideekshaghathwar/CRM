
const toggles = document.querySelectorAll("input[type='checkbox']");

toggles.forEach(toggle => {
    toggle.addEventListener("change", function () {
        console.log("Toggle state:", this.checked);
    });
});
